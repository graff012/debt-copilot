---
name: Precision Ledger & Recovery
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#4e45d5'
  on-secondary: '#ffffff'
  secondary-container: '#6860ef'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002114'
  on-tertiary-container: '#069669'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#e3dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#100069'
  on-secondary-fixed-variant: '#372abf'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-table-head:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  badge-label:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.01em
  tabular-numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.02em
  tabular-numeric-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  tabular-numeric-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2: 2px
  space-4: 4px
  space-6: 6px
  space-8: 8px
  space-10: 10px
  space-12: 12px
  space-16: 16px
  space-20: 20px
  space-24: 24px
  space-32: 32px
  sidebar-collapsed: 64px
  sidebar-expanded: 240px
  table-row-compact: 34px
  table-row-normal: 42px
---

## Brand & Style

This design system establishes a high-density, professional, and audit-grade operational interface tailored for wholesale distributors, credit controllers, and recovery specialists managing multi-tier receivables.

### Aesthetic Movement: High-Utility Swiss Modernism & Data Density
- **Functional Clarity:** Visual embellishments are eliminated in favor of information architecture, strict 4px grid alignments, and high-visibility status indicators.
- **Reliability & Authority:** The UI evokes institutional rigor, financial accuracy, and calm execution under high-volume workloads.
- **Cognitive Ergonomics:** Monospaced and tabular figures ensure numbers align vertically across dense grids; status color pairings are instant and unambiguous.

## Colors

The palette enforces clear typographic hierarchy against clean white working cards and a tinted background base. Semantic functional colors are paired with light tinted fills and saturated border rings for rapid scanning.

### Core Architecture
- **Surface Canvas (App Background):** `#f8fafc` (Slate 50)
- **Surface Elevation (Cards, Drawers, Modals):** `#ffffff` (Pure White)
- **Primary Ink (Headings, Key Financial Values):** `#0f172a` (Slate 900)
- **Secondary Ink (Body, Table Cells, Form Labels):** `#334155` (Slate 700)
- **Muted Ink (Meta, Timestamps, Table Headers):** `#64748b` (Slate 500)
- **Structural Dividers & Outlines:** `#e2e8f0` (Slate 200)
- **Subtle Table Hover Fill:** `#f1f5f9` (Slate 100)

### Functional & Semantic Tiers
- **Collected / Settled / Verified (Emerald):**
  - Text: `#059669`
  - Icon/Solid: `#10b981`
  - Background Tint: `#ecfdf5`
  - Border Ring: `#a7f3d0`
- **Critical / Overdue / Default Risk (Crimson):**
  - Text: `#dc2626`
  - Icon/Solid: `#ef4444`
  - Background Tint: `#fef2f2`
  - Border Ring: `#fecaca`
- **Due Soon / PTP Pending (Amber):**
  - Text: `#d97706`
  - Icon/Solid: `#f59e0b`
  - Background Tint: `#fffbeb`
  - Border Ring: `#fde68a`
- **Audit / Legal Escalation (Indigo):**
  - Text: `#4338ca`
  - Icon/Solid: `#6366f1`
  - Background Tint: `#eef2ff`
  - Border Ring: `#c7d2fe`

## Typography

The typography strategy prioritizes horizontal scanning and high-density line heights:
- **Primary Typeface (Hanken Grotesk):** Clean, geometric grotesque optimized for high screen legibility at small sizes (11px–14px).
- **Tabular Monospace (JetBrains Mono):** Mandated for all monetary figures (UZS sums, aging intervals, settlement ratios, and invoice numbers) with `font-variant-numeric: tabular-nums lining-nums`.
- **Case Rule:** Table column headers and section labels are styled in small uppercase (`text-transform: uppercase`) with subtle tracking (+0.04em) in `#64748b`.

## Layout & Spacing

A compact, structured, fixed-sidebar layout designed for desktop workflows (1366px - 1920px+) with strict responsiveness down to mobile views.

### Structure
- **Persistent Left Navigation:** 240px fixed width (collapsible to 64px icon-only rail). Houses main collection stages, customer directory, batch operations, integrations, and operational alerts.
- **Top Utility Strip:** 48px height containing global debtor search, quick collection action trigger, fiscal period switch, and debt collector profile.
- **Main Working Canvas:** Dynamic width with a maximum container threshold of 1600px centered in ultra-wide screens, bounded by 20px edge margins.
- **Grid Architecture:** 12-column dynamic flex grid with 12px gutters for standard cards; metrics cards run on 4 or 6 column spans.

### Breakpoints & Density Modes
- **Compact View (Desktop Default):** Table cell padding is 8px horizontal, 6px vertical; card padding is 14px to 16px.
- **Tablet / Lower Bounds (1024px):** Auxiliary metrics collapse into 2-row blocks; tables enable pinned horizontal scrolling with sticky customer name columns.

## Elevation & Depth

This system avoids heavy theatrical drop shadows, relying on structural borders, micro-hairlines, and flat tonal differentiation.

### Elevation Hierarchy
- **Level 0 (App Shell Background):** `#f8fafc`, flat canvas.
- **Level 1 (Card & Module Containers):** `#ffffff`, bordered with a 1px continuous hairline (`#e2e8f0`). No shadow or micro-shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Level 2 (Active Dropdown Menus, Context Popovers):** `#ffffff`, bordered with 1px `#cbd5e1`, shadow: `0 4px 12px -2px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Action Drawers, Recovery Log Modals):** `#ffffff`, 1px border `#cbd5e1`, shadow: `0 16px 32px -6px rgba(15, 23, 42, 0.14)`. Backdrop filter is standard `rgba(15, 23, 42, 0.45)` with subtle `backdrop-blur(2px)`.

## Shapes

The design uses tight, geometric corner radii (Soft / `roundedness: 1`) to preserve data real estate and convey analytical discipline.

### Radius Matrix
- **Data Table Cells & List Rows:** `0px` (seamless full-width striping).
- **Buttons, Inputs, Select Boxes:** `4px` (`rounded-sm`).
- **Cards, Panels, Overview Modules:** `6px` (`rounded`).
- **Pills, Operational Status Badges, Avatar Nodes:** `9999px` (`rounded-full`).

## Components

### Buttons
- **Primary:** Solid `#0f172a` fill, white text, 4px border radius. Height: 32px (compact), 8px 12px padding. Hover: `#1e293b`. Focus: 2px ring offset with `#4338ca`.
- **Secondary / Action:** `#ffffff` fill, 1px border `#cbd5e1`, text `#334155`. Hover: `#f8fafc`.
- **Destructive:** `#fef2f2` fill, 1px border `#fecaca`, text `#dc2626`. Hover: `#fee2e2`.
- **Icon Quick-Action (Table inline):** 24px × 24px square, text `#64748b`, hover: `#f1f5f9` with `#0f172a` icon.

### Status Pills & Aging Badges
- **Overdue 90+ Days:** `#fef2f2` background, `#dc2626` text, `#fecaca` outline, 11px font weight 600.
- **Due within 7 Days:** `#fffbeb` background, `#d97706` text, `#fde68a` outline.
- **Recovered / PTP Honored:** `#ecfdf5` background, `#059669` text, `#a7f3d0` outline.
- **Disputed / Blocked:** `#f1f5f9` background, `#475569` text, `#cbd5e1` outline.

### Data Tables (Receivables Ledger)
- **Header:** Height 32px, background `#f8fafc`, 1px bottom border `#e2e8f0`. Text: 11px uppercase Slate 500.
- **Row:** Height 36px–40px, white background, hover background `#f8fafc`, 1px bottom border `#f1f5f9`.
- **Number Alignment:** Tabular numbers aligned to the right. Format: `142,500,000 UZS` with thin-space or comma thousands separation.
- **Checkboxes:** 14px × 14px crisp square, 2px corner radius, primary slate accent when checked.

### Form Inputs & Search Fields
- Height: 32px.
- Background: `#ffffff`, 1px border `#cbd5e1`. Active focus state transitions to border `#4338ca` with a 2px `rgba(67, 56, 202, 0.15)` focus glow.
- Internal padding: 6px 10px. Label sits 4px above input in 11px semi-bold Slate 700.

### Metric KPI Tiles
- Crisp `#ffffff` container, 1px `#e2e8f0` border, 12px 14px padding.
- Top label: 11px uppercase Slate 500.
- Value: 20px or 24px monospaced Slate 900 bold.
- Bottom subtext: Inline badge indicating weekly recovery delta (+12.4% vs last week) in Emerald or Crimson.